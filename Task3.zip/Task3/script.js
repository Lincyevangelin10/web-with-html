// script.js
let isChatVisible = false;
const chatBox = document.getElementById("chatBox");
const messages = document.getElementById("messages");
const userInput = document.getElementById("userInput");

// Toggle the visibility of the chat window
function toggleChat() {
    isChatVisible = !isChatVisible;
    chatBox.style.display = isChatVisible ? "block" : "none";
}

// Handle Enter key press for sending messages
function handleKeyPress(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}

// Display the user's message in the chat box
function displayUserMessage(message) {
    const messageElem = document.createElement("div");
    messageElem.classList.add("user-message");
    messageElem.textContent = message;
    messages.appendChild(messageElem);
}

// Display the bot's response in the chat box
function displayBotResponse(message) {
    const messageElem = document.createElement("div");
    messageElem.classList.add("bot-message");
    messageElem.textContent = message;
    messages.appendChild(messageElem);
    messages.scrollTop = messages.scrollHeight;  // Scroll to the bottom
}

// Send message from the user to the bot
function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    displayUserMessage(message);
    userInput.value = "";  // Clear input field

    // Simple AI responses (can be replaced with API calls to a backend or AI model)
    let botResponse = "I'm not sure how to answer that.";
    if (message.toLowerCase().includes("routes")) {
        botResponse = "We have routes to New York, Chicago, and Los Angeles.";
    } else if (message.toLowerCase().includes("book")) {
        botResponse = "I can help you with the booking process. Please provide the details.";
    } else if (message.toLowerCase().includes("schedule")) {
        botResponse = "The next available schedule is 9 AM tomorrow.";
    }

    // Display bot response
    displayBotResponse(botResponse);
}
